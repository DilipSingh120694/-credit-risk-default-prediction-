# Figure Provenance

These eight PNGs were extracted unchanged from Dilip Singh Rajpurohit's submitted report. Duplicate appendix images were omitted. They are model/analysis figures, not Power BI dashboard screenshots.

| File | Original figure |
| --- | --- |
| `eda-credit-risk.png` | Figure 1: Exploratory analysis |
| `logistic-regression-confusion-matrix.png` | Figure 2 |
| `logistic-regression-coefficients.png` | Figure 3 |
| `decision-tree-confusion-matrix.png` | Figure 4 |
| `decision-tree-feature-importance.png` | Figure 5 |
| `decision-tree-structure.png` | Figure 6 |
| `model-accuracy-comparison.png` | Figure 7 |
| `income-by-default-status.png` | Figure 8 |

The README and technical review explain contradictions between the original text and these figures. The income image's currency and exact p-value are not independently verified. Do not read raw coefficients across different units as a universal importance ranking.
